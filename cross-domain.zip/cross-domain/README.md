# cross-domind

### 跨域请求视频讲解

#### 跨域接口地址: http://www.thenewstep.cn/test/testToken.php

#### 参数: username, password

#### token: f4c902c9ae5a2a9d8f84868ad064e706

#### 请求类型: post

#### 请求头: Content-type:application/json

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
